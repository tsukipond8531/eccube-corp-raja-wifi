Google PHP API Client Services
==============================

## Requirements

[Google API PHP Client](https://github.com/googleapis/google-api-php-client/releases)

## Usage

This library is automatically updated daily with new API changes, and tagged weekly.
It is installed as part of the 
[Google API PHP Client](https://github.com/googleapis/google-api-php-client/releases)
library via Composer, which will pull down the most recent tag.
