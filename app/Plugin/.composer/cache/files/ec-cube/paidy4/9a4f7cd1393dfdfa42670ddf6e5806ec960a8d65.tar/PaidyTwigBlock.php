<?php

namespace Plugin\Paidy4;

use Eccube\Common\EccubeTwigBlock;

class PaidyTwigBlock implements EccubeTwigBlock
{
    /**
     * @return array
     */
    public static function getTwigBlock()
    {
        return [
        ];
    }
}
